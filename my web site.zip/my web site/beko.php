<?php
echo"hello this is my web";
?>